package ch06.sec06.exam01;

public class Car {
	String model;
	boolean start;
	int speed;

}
